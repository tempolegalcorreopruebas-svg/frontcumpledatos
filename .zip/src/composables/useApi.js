import { ref } from 'vue'
import api from '../services/api'

export function useApi() {
  const data = ref(null)
  const loading = ref(false)
  const error = ref(null)

  const request = async (config) => {
    loading.value = true
    error.value = null

    try {
      const response = await api.request(config)

      data.value = response.data

      return response.data
    } catch (requestError) {
      const validationErrors = requestError.response?.data?.errors

      if (validationErrors) {
        error.value = Object.values(validationErrors).flat()[0]
      } else {
        error.value =
          requestError.response?.data?.message ||
          requestError.message ||
          'No fue posible comunicarse con el servidor.'
      }

      throw requestError
    } finally {
      loading.value = false
    }
  }

  const get = (url, params = {}, config = {}) => {
    return request({
      ...config,
      method: 'GET',
      url,
      params,
    })
  }

  const post = (url, payload = {}, config = {}) => {
    return request({
      ...config,
      method: 'POST',
      url,
      data: payload,
    })
  }

  const put = (url, payload = {}, config = {}) => {
    return request({
      ...config,
      method: 'PUT',
      url,
      data: payload,
    })
  }

  const patch = (url, payload = {}, config = {}) => {
    return request({
      ...config,
      method: 'PATCH',
      url,
      data: payload,
    })
  }

  const remove = (url, config = {}) => {
    return request({
      ...config,
      method: 'DELETE',
      url,
    })
  }

  const reset = () => {
    data.value = null
    error.value = null
    loading.value = false
  }

  return {
    data,
    loading,
    error,
    get,
    post,
    put,
    patch,
    remove,
    reset,
  }
}