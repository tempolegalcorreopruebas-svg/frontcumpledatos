const SESSION_KEY = 'cumplidatos_session'

const demoUser = {
  id: 1,
  name: 'Administrador Demo',
  email: 'admin@cumplidatos.local',
  role: 'super_admin',
}

const demoPassword = 'Demo123*'

const login = async (email, password) => {
  await new Promise((resolve) => setTimeout(resolve, 600))

  const normalizedEmail = email.trim().toLowerCase()

  if (
    normalizedEmail !== demoUser.email ||
    password !== demoPassword
  ) {
    throw new Error('El correo o la contraseña son incorrectos.')
  }

  sessionStorage.setItem(
    SESSION_KEY,
    JSON.stringify(demoUser),
  )

  return demoUser
}

const logout = () => {
  sessionStorage.removeItem(SESSION_KEY)
}

const getUser = () => {
  const session = sessionStorage.getItem(SESSION_KEY)

  if (!session) {
    return null
  }

  try {
    return JSON.parse(session)
  } catch {
    sessionStorage.removeItem(SESSION_KEY)
    return null
  }
}

const isAuthenticated = () => {
  return getUser() !== null
}

/*
 * Conservamos authService para que el código existente
 * continúe funcionando.
 */
export const authService = {
  login,
  logout,
  getUser,
  isAuthenticated,
}

/*
 * Composable que permite desestructurar los métodos.
 */
export function useAuth() {
  return {
    login,
    logout,
    getUser,
    isAuthenticated,
  }
}