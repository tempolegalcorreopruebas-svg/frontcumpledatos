import { useApi } from "@/composables/useApi";

const { post, get } = useApi();

const USER_KEY = "auth_user";

/*
|--------------------------------------------------------------------------
| LOGIN CENTRAL
|--------------------------------------------------------------------------
*/

const login = async (email, password) => {
  const response = await post("/api/v1/auth/login", {
    email,
    password,
  });

  const loginData = response.data;

  if (loginData.contexto === "tenant") {
    redirectToTenant(
      loginData.subdomain,
      loginData.transfer_code
    );

    return;
  }

  if (loginData.contexto === "platform") {
    return loginData.user;
  }

  return response;
};


/*
|--------------------------------------------------------------------------
| REDIRECCIÓN AL TENANT
|--------------------------------------------------------------------------
*/

const redirectToTenant = (subdomain, transferCode) => {
  const centralDomain = import.meta.env.VITE_CENTRAL_DOMAIN;

  const url = new URL(window.location.origin);

  url.hostname = `${subdomain}.${centralDomain}`;
  url.pathname = "/auth/callback";

  url.search = "";
  url.searchParams.set("code", transferCode);

  console.log("Redirigiendo a:", url.toString());

  window.location.replace(url.toString());
};


/*
|--------------------------------------------------------------------------
| EXCHANGE
|--------------------------------------------------------------------------
*/

const exchange = async (code) => {
  await get("/sanctum/csrf-cookie");

  const response = await post(
    "/api/v1/auth/exchange",
    {
      code,
    }
  );

  return response.data;
};


/*
|--------------------------------------------------------------------------
| ME
|--------------------------------------------------------------------------
*/

const me = async () => {
  const response = await get("/api/v1/auth/me");

  const user = response.data.user;

  sessionStorage.setItem(
    USER_KEY,
    JSON.stringify(user)
  );

  return user;
};


/*
|--------------------------------------------------------------------------
| LOGOUT
|--------------------------------------------------------------------------
*/

const logout = async () => {
  try {
    await post("/api/v1/auth/logout");
  } finally {
    clearSession();
  }
};


/*
|--------------------------------------------------------------------------
| DATOS LOCALES
|--------------------------------------------------------------------------
*/

const clearSession = () => {
  sessionStorage.removeItem(USER_KEY);
};


const getUser = () => {
  const user = sessionStorage.getItem(USER_KEY);

  if (!user) {
    return null;
  }

  try {
    return JSON.parse(user);
  } catch {
    sessionStorage.removeItem(USER_KEY);

    return null;
  }
};


/*
|--------------------------------------------------------------------------
| AUTENTICACIÓN
|--------------------------------------------------------------------------
*/

const isAuthenticated = async () => {
  try {
    await me();

    return true;
  } catch {
    return false;
  }
};


export const authService = {
  login,
  exchange,
  me,
  logout,
  getUser,
  isAuthenticated,
  clearSession,
};


export function useAuth() {
  return {
    login,
    exchange,
    me,
    logout,
    getUser,
    isAuthenticated,
    clearSession,
  };
}